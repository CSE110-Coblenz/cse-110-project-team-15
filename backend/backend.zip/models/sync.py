from models.save import SaveState

class SyncResponse(SaveState):
    pass
